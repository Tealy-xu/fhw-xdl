<?php
use Org\Util\Ueditor;
$st =   new SaeStorage();
return array(
	//'配置项'=>'配置值'
	'FILE_UPLOAD_TYPE' => 'Sae',
);