<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
        $this->display();
    }
    
    public function ueditor(){
    	$data = new \Org\Util\Ueditor();
		echo $data->output();
    }
}